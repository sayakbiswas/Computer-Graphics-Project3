
Team Member - Mohan Zalake (37838993)
Videolink:  https://youtu.be/8oXnT7Jbyb8


Instructions:
Press left right up and left arrow key to rotate your camera.
Press 'f' to display face.
Press 'r' to reset
Press 'c' to show control mesh 
Press 'z' to fit point to your face
Press 't' to fit points points laterally
Press 'a' to sub-divide your surface
Press 'h' to view hairs.
Press 's' to save control points.
Press 'l' to load saved control points.
 
