#ifndef TESSSHADER
#define TESSSHADER

GLuint LoadTessShaders(const char * tess_control_file_path,const char * tess_eval_file_path, const char * vertex_file_path,const char * fragment_file_path);

#endif
